export interface Message {
    text: string;
    ownerId: number,
    createdAt: number;
}