import { Component } from '@angular/core';

@Component({
    selector: 'app-accessdenied',
    templateUrl: './accessdenied.component.html'
})
export class AccessdeniedComponent { }
