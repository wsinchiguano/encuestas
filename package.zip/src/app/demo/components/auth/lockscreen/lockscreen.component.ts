import { Component } from '@angular/core';

@Component({
    templateUrl: './lockscreen.component.html'
})
export class LockScreenComponent { }