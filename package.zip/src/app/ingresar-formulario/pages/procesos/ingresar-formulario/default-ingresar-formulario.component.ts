import { Component } from '@angular/core';

@Component({
  selector: 'app-default-ingresar-formulario',
  templateUrl: './default-ingresar-formulario.component.html',
  styleUrls: ['./default-ingresar-formulario.component.css']
})
export class DefaultIngresarFormularioComponent {

}
