
export interface CategoriaInterface {
    id_categoria: number;
    nombre_categoria: string;
    estado_categoria: string;
    user_created_categoria: string;
    date_created_categoria: string;
    user_updated_categoria: null;
    date_updated_categoria: null;
}
